<a href="mhs.php">LIHAT</a>
<a href="mhs_add.php">TAMBAH</a>